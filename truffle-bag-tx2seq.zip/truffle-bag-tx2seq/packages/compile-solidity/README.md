# @truffle/compile-solidity
Compiler helper and artifact manager for Solidity files
