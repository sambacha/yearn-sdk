import * as Encode from "./encode";
export {
  /**
   * @protected
   */
  Encode
};
