webpack --config=cli.webpack.config.js --profile --json > stats.json && webpack-bundle-analyzer stats.json
