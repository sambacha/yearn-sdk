import "source-map-support/register";

import { Resolver } from "./resolver";
import { ResolverSource } from "./source";

export { Resolver, ResolverSource };

module.exports = Resolver;
