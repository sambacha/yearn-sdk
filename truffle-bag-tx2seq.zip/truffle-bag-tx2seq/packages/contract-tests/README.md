# `@truffle/contract-tests`

:information_source: This package houses the tests for
[@truffle/contract](https://www.npmjs.com/package/@truffle/contract). This
package is not published and lives only in this monorepo.
