# @truffle/solidity-utils
Utilities for solidity contracts

# API

### ordered_abi(file_path, abi, contract_name, callback)

Given a path to a file, an abi, and a contract name, return a restructured abi where the functions are ordered in the exact order they appear in the source file.

TODO: Example

###
