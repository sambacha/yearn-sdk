# @truffle/provider
Beefed up Provider utility for Truffle

The goal of this module is to turn it into a provider object that contains extra utility methods that apply to the provider; however, in it's current state it simply a set of standalone utility functions.
